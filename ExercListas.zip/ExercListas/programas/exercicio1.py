
"""
Escreva um programa em Python que, considerando uma string digitada pelo usuário,
 converta-a em letras minúsculas e, em seguida, exiba os caracteres na vertical (um debaixo do outro).
"""




str_exe1 = input("Digite a string desejada: ")

str_minuscula = str_exe1.lower()

tam = len(str_minuscula)

for i in range (tam):
    print(str_minuscula[i])
